<!-- Plugin JS File -->
<script src="<?=base_url()?>assets/frontend/vendor/jquery/jquery.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/parallax/parallax.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/jquery.plugin/jquery.plugin.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/skrollr/skrollr.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/zoom/jquery.zoom.js"></script>
<script src="<?=base_url()?>assets/frontend/vendor/jquery.countdown/jquery.countdown.min.js"></script>

<script src="<?=base_url()?>assets/frontend/js/lobibox.js"></script>
<script src="<?=base_url()?>assets/frontend/js/notification.js"></script>
<!-- Main JS -->
<script src="<?=base_url()?>assets/frontend/js/main.min.js"></script>