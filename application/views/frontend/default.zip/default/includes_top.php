<link rel="preload" href="<?=base_url()?>assets/frontend/vendor/fontawesome-free/webfonts/fa-regular-400.woff2" as="font" type="font/woff2"
        crossorigin="anonymous">
<link rel="preload" href="<?=base_url()?>assets/frontend/vendor/fontawesome-free/webfonts/fa-solid-900.woff2" as="font" type="font/woff2"
        crossorigin="anonymous">
<link rel="preload" href="<?=base_url()?>assets/frontend/vendor/fontawesome-free/webfonts/fa-brands-400.woff2" as="font" type="font/woff2"
            crossorigin="anonymous">
<link rel="preload" href="<?=base_url()?>assets/frontend/fonts/wolmart87d5.ttf?png09e" as="font" type="font/ttf" crossorigin="anonymous">

    <!-- Vendor CSS -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/vendor/fontawesome-free/css/all.min.css">

   <!-- Plugins CSS -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/vendor/swiper/swiper-bundle.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/vendor/animate/animate.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/vendor/magnific-popup/magnific-popup.min.css">

<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/css/lobibox.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/css/navigation.css">
    <!-- Default CSS -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/frontend/css/style.css">